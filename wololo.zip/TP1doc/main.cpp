# include "Duree.h"




int main(){
   Duree t;
   t.SecondeToDuree(3700);
   t.afficher();

   return 0;
}





















