#ifndef CHAINE_H
#define CHAINE_H
#include <iostream>
using namespace std;


class Chaine{


private:

char* tab;


public:

Chaine();
Chaine(char);
Chaine(char*);
Chaine(const Chaine&);









};























#endif